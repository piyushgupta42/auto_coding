<?php

namespace Drupal\my_custom_module\Plugin\Block;


use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;


/**
 * Provides a block with a simple text.
 *
 * @Block(
 *   id = "my_custom_block",
 *   admin_label = @Translation("custom block module: basic"),
 *   category = "custom block"
 * )
 */
class MyCustomBlock extends BlockBase
{

  /**
   * {@inheritdoc}
   */
  public function build()
  {
    $form = \Drupal::formBuilder()->getForm('Drupal\my_custom_module\Form\SimpleCustomForm');
    return [
      '#markup' => 'This is a simple block that displays Custom form Module!',
      'form' => $form

    ];
  }

  public function blockForm($form, FormStateInterface $form_state): array
  {
    $form = parent::blockForm($form, $form_state);

    // Retrieve the blocks configuration as the values provided in the form
    // are stored there.
    $config = $this->getConfiguration();

    // The form field is defined and added to the form array here.
    $form['message'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Message'),
      '#description' => $this->t('Type the message you want visitors to see'),
      '#default_value' => $config['message'] ?? '',
    ];

    return $form;
  }
}
