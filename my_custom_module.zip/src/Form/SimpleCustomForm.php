<?php

namespace Drupal\my_custom_module\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Psr7\Response;
use Psr\Http\Message\ResponseInterface;
use GuzzleHttp\Exception\RequestException;

class SimpleCustomForm extends FormBase
{
  /**
   * {@inheritdoc}
   */
  public function getFormId()
  {
    // Here we set a unique form id
    return 'simple_custom_form';
  }
  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state)
  {
    $number = range(1995, 2023);
    foreach ($number as $value) {
      $years = $value;
    };
    $options = array();

    $client = new \GuzzleHttp\Client();
    $response = $client->request(
      'GET',
      'https://vpic.nhtsa.dot.gov/api/vehicles/GetModelsForMakeIdYear/makeId/474/modelyear/' . $years . '/vehicleType/truck?format=json'
    );
    $response->getStatusCode(); // 200
    $contents = $response->getBody()->getContents();
    $result = json_decode($contents, true);

    foreach ($result as $finalr) {
      //var_dump($finalr);
      foreach ($finalr as $key => $value) {
        //var_dump($value);
        $make1 = $value['Make_Name'];
        $model1 = $value['Model_Name'];
        // $options[$value->Make_Name] = $value->Make_Name;
        // echo '<pre>';
        // echo $make1;
        // echo '</pre>';
      }
    }

    $year = array(
      $number
    );

    $make = array(
      $make1
    );
    $model = array(
      $model1
    );
    // $engine = array(
    //   '0' => '4 | Engine',
    //   '1' => '6 cylender ',

    // );

    $form['year'] = array(
      '#type' => 'select',
      '#title' => ('Year'),
      '#title_display' => 'invisible',
      '#attributes' => ['class' => ['container-inline form-control']],
      '#empty_option' => '1 | Year',
      '#prefix' => '<div id="example-fieldset-wrapper year">',
      '#suffix' => '</div>',
      '#options' => $year,
      //'#default_value' => $default_option,
    );
    $form['make'] = array(
      '#type' => 'select',
      '#title' => ('Make'),
      '#title_display' => 'invisible',
      '#attributes' => ['class' => ['container-inline form-control']],
      '#empty_option' => '2 | Make',
      '#options' => $make
    );
    $form['model'] = array(
      '#type' => 'select',
      '#title' => ('Model'),
      '#title_display' => 'invisible',
      '#attributes' => ['class' => ['container-inline form-control']],
      '#empty_option' => '3 | Model',
      '#options' => $model
    );
    // $form['engine'] = array(
    //   '#type' => 'select',
    //   '#title' => ('Engine'),
    //   '#title_display' => 'invisible',
    //   '#attributes' => ['class' => ['container-inline form-control']],
    //   '#options' => $engine
    // );

    return $form;
  }

  public function validateForm(array &$form, FormStateInterface $form_state)
  {
    // Here we decide whether the form can be forwarded to the submitForm()
    // function or should be sent back to the user to fix some information.
  }

  public function submitForm(array &$form, FormStateInterface $form_state)
  {
  }
}
