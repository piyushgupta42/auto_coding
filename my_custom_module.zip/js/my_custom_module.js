(function($){
 $(document).ready(function(){
  'use strict';
    $("#edit-make").prop("disabled", true);
    $("#edit-model").prop("disabled", true);
    //$("#edit-engine").prop("disabled", true);
    $("#edit-year").change(function () {
        var currval = $('#edit-year').val();
        if(currval!=="") {
            $("#edit-make").prop("disabled", false);
            $("#edit-model").prop("disabled", true);
           // $("#edit-engine").prop("disabled", true);
        }
    });
    $("#edit-make").change(function () {
        var currval = $('#edit-make').val();
        if(currval!=="") {
          $("#edit-model").prop("disabled", false);
         // $("#edit-engine").prop("disabled", true);
        }
    });
    $("#edit-model").change(function () {
        var currval = $('#edit-model').val();
        if(currval!=="") {
                $("#edit-engine").prop("disabled", false);
        }
    });

 });
  // $.ajax({
  //       url: "https://api.github.com/repos/guzzle/guzzle"
  //   }).then(function(data) {
  //      console.log(data);
  //      $('#edit-year').append(data.id);
  //      $('#edit-model').append(data.content);
  //   });

    // $('optgroup[label=0]').attr('disabled', true)
    // $('optgroup[label=0]').attr('hidden', true)
})(jQuery);
